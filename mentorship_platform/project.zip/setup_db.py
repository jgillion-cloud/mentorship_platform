import sqlite3

# Connect to database (creates it if it doesn't exist)
conn = sqlite3.connect('mentorship.db')
cursor = conn.cursor()

# Table 1: users
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    user_type TEXT NOT NULL CHECK(user_type IN ('highschool', 'college')),
    username TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
''')

# Table 2: college_profiles
cursor.execute('''
CREATE TABLE IF NOT EXISTS college_profiles (
    user_id INTEGER PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    university TEXT NOT NULL,
    hometown TEXT,
    help_areas TEXT,
    availability TEXT,
    academic_interests TEXT,
    gender TEXT,
    race TEXT,
    is_international INTEGER,
    is_athlete INTEGER,
    is_lgbtq INTEGER,
    religion TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
)
''')

# Table 3: requests
cursor.execute('''
CREATE TABLE IF NOT EXISTS requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_user_id INTEGER NOT NULL,
    to_user_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    meet_link TEXT NOT NULL,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'accepted', 'rejected')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (from_user_id) REFERENCES users(id),
    FOREIGN KEY (to_user_id) REFERENCES users(id)
)
''')

# Table 4: meetings
cursor.execute('''
CREATE TABLE IF NOT EXISTS meetings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id INTEGER NOT NULL,
    meeting_date TIMESTAMP,
    is_completed INTEGER DEFAULT 0,
    FOREIGN KEY (request_id) REFERENCES requests(id)
)
''')

conn.commit()
conn.close()

print("Database created successfully!")